include("../../src/Interior_Point_Method/quadratic/ipqp.jl");
include("../../src/BAN.jl");
import LinearAlgebra
using .BAN

# NOTICE! tolerance with Interior Point Method must be 1e-8 (because in BAN.jl it is the tolerance used for some denoise)
#=
SIMPLE DISJUNCTIVE PROBLEM - BIG-M REFORMULATION + Interior Point Method
This script tries to solve a simple disjunctive-constraints problem using the
Big-M reformulation and the (Quadratic) Interior Point Method
The solution found is not correct!
This topic is described in subsections 1.10 and 1.10.1
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#

# objective function: y1(1-y1)α^2 + c'x

Q = [ 0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0 -α^2 0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
      0  0  0  0  0  0  0  0  0  0  0  0;
    ];

Q = convert(Matrix{Ban}, Q);

M = α;

A = [#x1  x2  y1  s1  s2  s3  s4  s5  s6  s7  s8  y2
      1   0   M   1   0   0   0   0   0   0   0   0; # x1 + My1 + s1 = M + 3
      1   0  -M   0  -1   0   0   0   0   0   0   0; # x1 - My1 - s2 = -M
      0   1   M   0   0   1   0   0   0   0   0   0; # x2 + My1 + s3 = M + 4
      0   1  -M   0   0   0  -1   0   0   0   0   0; # x2 - My1 - s4 = -M
      1   0  -M   0   0   0   0   1   0   0   0   0; # x1 - My1 + s5 = 9
      1   0   M   0   0   0   0   0  -1   0   0   0; # x1 + My1 - s6 = 5
      0   1  -M   0   0   0   0   0   0   1   0   0; # x2 - My1 + s7 = 6
      0   1   M   0   0   0   0   0   0   0  -1   0; # x2 + My1 - s8 = 4
      0   0   1   0   0   0   0   0   0   0   0   1; # y1 + y2 = 1
    ];

A = convert(Matrix{Ban}, A);

b = [ M+3, -M, M+4, -M, 9, 5, 6, 4, 1 ];

# maximize -1 -1
c = [ 1, 1, α^2, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];

# maximize 1 1
#NOTICE: you must also change the sign of α^2 in Q and make it positive
#NOTICE: error singularException after a few iterations
#c = [ -1, -1, -α^2, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];


tol=1e-8;
verbose = true;
genLatex = false;

sol = ipqp(A,b,c,Q, tol; maxit=20, verbose=verbose, genLatex=genLatex, slack_var=4:12);

print("The end")
