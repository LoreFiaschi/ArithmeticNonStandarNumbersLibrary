include("../../src/Interior_Point_Method/quadratic/ipqp.jl");
include("../../src/BAN.jl");
import LinearAlgebra
using .BAN

# NOTICE! tolerance with Interior Point Method must be 1e-8 (because in BAN.jl it is the tolerance used for some denoise)
#=
SIMPLE DISJUNCTIVE PROBLEM - CONVEX HULL REFORMULATION + Interior Point Method
This script tries to solve a simple disjunctive-constraints problem using the
Convex Hull reformulation and the (Quadratic) Interior Point Method.
The solution found is not correct!
This topic is described in subsections 1.10 and 1.10.1
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#

# objective function: y1(1-y1)α^2 + c'x

M = α

A = [#x11 x21 x12 x22 y1  s1  s2  s3  s4  s5  s6  s7  s8  s9  s10 s11 s12 s13 s14  x1  x2  y2
       1   0   0   0   0  -1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0; # x11 - s1 = 0
       1   0   0   0  -M   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0; # x11 - My1 + s2 = 0
       1   0   0   0  -3   0   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0; # x11 - 3y1 + s3 = 0
       0   1   0   0   0   0   0   0  -1   0   0   0   0   0   0   0   0   0   0   0   0   0; # x21 - s4 = 0
       0   1   0   0  -M   0   0   0   0   1   0   0   0   0   0   0   0   0   0   0   0   0; # x21 - My1 + s5 = 0
       0   1   0   0  -4   0   0   0   0   0   1   0   0   0   0   0   0   0   0   0   0   0; # x21 - 4y1 + s6 = 0
       0   0   1   0   0   0   0   0   0   0   0  -1   0   0   0   0   0   0   0   0   0   0; # x12 - s7 = 0
       0   0   1   0   M   0   0   0   0   0   0   0   1   0   0   0   0   0   0   0   0   0; # x12 + My1 + s8 = M
       0   0   1   0   5   0   0   0   0   0   0   0   0  -1   0   0   0   0   0   0   0   0; # x12 + 5y1 - s9 = 5
       0   0   1   0   9   0   0   0   0   0   0   0   0   0   1   0   0   0   0   0   0   0; # x12 + 9y1 -s10 = 9
       0   0   0   1   0   0   0   0   0   0   0   0   0   0   0  -1   0   0   0   0   0   0; # x22 -s11 = 0
       0   0   0   1   M   0   0   0   0   0   0   0   0   0   0   0   1   0   0   0   0   0; # x22 + My1 + s12 = M
       0   0   0   1   4   0   0   0   0   0   0   0   0   0   0   0   0  -1   0   0   0   0; # x22 + 4y1 - s13 = 4
       0   0   0   1   6   0   0   0   0   0   0   0   0   0   0   0   0   0   1   0   0   0; # x22 + 6y1 + s14 = 6
       1   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0  -1   0   0; # x11 + x12 - x1 = 0
       0   1   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0  -1   0; # x21 + x22 - x2 = 0
       0   0   0   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   1; # y1 + y2 = 1
    ];

Q = zeros(size(A,2), size(A,2));
Q = convert(Matrix{Ban}, Q);
Q[5,5] = α^2;

b = [ 0, 0, 0, 0, 0, 0, 0, M, 5, 9, 0, M, 4, 6, 0, 0, 1 ];

# maximize -1 -1
# NOTICE: you must also change the sign of α^2 in Q and make it negative
#c = [1, 1, 1, 1, α^2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0];

# maximize 1 1
c = [-1, -1, -1, -1, -α^2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0];


tol=1e-8;
verbose = true;
genLatex = false;

sol = ipqp(A,b,c,Q, tol; maxit=20, verbose=verbose, genLatex=genLatex, slack_var=6:22);

print("The end")
