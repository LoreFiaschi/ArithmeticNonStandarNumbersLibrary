include("../../src/Interior_Point_Method/quadratic/ipqp.jl");
include("../../src/BAN.jl");

using .BAN

# NOTICE! tolerance with Interior Point Method must be 1e-8 (because in BAN.jl it is the tolerance used for some denoise)

#=
STANDARD KYTE PROBLEM - INTERIOR POINT METHOD
This script solves the Standard Kyte problem using the (Quadratic) Interior Point Method.
This topic is described in subsection 1.7.
The problem is described at the following link:
https://link.springer.com/article/10.1007/s11590-020-01644-6
=#

# Matrix Q is all zeros because the objective function is linear
Q = zeros(7,7)

c = [-8, -12, -7, 0, 0, 0, 0];

b = [90, 190, 300, 10, 70];

	#z1 z2  z3  s1  s2  s3  s4
A = [2   1  -3   1   0   0   0; # 2 z1 + z2 - 3 z3 + s1 = 90
     2   3  -2   0   1   0   0; # 2 z1 + 3 z2 - 2 z3 + s2 = 190
     4   3   3   0   0   1   0; # 4 z1 + 3 z2 + 3 z3 + s3 = 300
	 0   0   1   0   0   0   0; # z3 = 10
     1   2   1   0   0   0  -1]; # z1 + 2 z2 - z3 - s4 = 0

A = convert(Matrix{Ban}, A);

tol=1e-8;
genLatex = false;
verbose = true;

sol = ipqp(A,b,c,Q, tol; maxit=30, verbose=verbose, genLatex=genLatex, slack_var=3:6);

println("The end");
