include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");

using .BAN

#=
SIMPLE DISJUNCTIVE PROBLEM - CONVEX HULL REFORMULATION + NA SIMPLEX
This script solves a simple disjunctive-constraints problem using the
Convex Hull reformulation and the NA Simplex.
This topic is described in subsection 1.4.1.
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#

M = α

A = [#  x1 x2  x11 x21 x12 x22 y1  y2  s1  s2  s3  s4  s5  s6  s7  s8  s9  s10 s11 s12 s13 s14
       -1   0   1   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0;  # -x1 + x11 + x12 = 0
        0  -1   0   1   0   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0;  # -x2 + x21 + x22 = 0
        0   0   0   0   0   0   1   1   0   0   0   0   0   0   0   0   0   0   0   0   0   0;  # y1 + y2 = 1
        0   0   1   0   0   0   0   0  -1   0   0   0   0   0   0   0   0   0   0   0   0   0;  # x11 - s1 = 0
        0   0   1   0   0   0  -M   0   0   1   0   0   0   0   0   0   0   0   0   0   0   0;  # x11 - M y1 + s2 = 0
        0   0   1   0   0   0  -3   0   0   0   1   0   0   0   0   0   0   0   0   0   0   0;  # x11 - - 3 y1 + s3 = 0
        0   0   0   1   0   0   0   0   0   0   0  -1   0   0   0   0   0   0   0   0   0   0;  # x21 - s4 = 0
        0   0   0   1   0   0  -M   0   0   0   0   0   1   0   0   0   0   0   0   0   0   0;  # x21 - M y1 + s5 = 0
        0   0   0   1   0   0  -4   0   0   0   0   0   0   1   0   0   0   0   0   0   0   0;  # x21 - 4 y1 + s6 = 0
        0   0   0   0   1   0   0   0   0   0   0   0   0   0  -1   0   0   0   0   0   0   0;  # x12 - s7 = 0
        0   0   0   0   1   0   0  -M   0   0   0   0   0   0   0   1   0   0   0   0   0   0;  # x12 - M y2 + s8 = 0
        0   0   0   0   1   0   0  -5   0   0   0   0   0   0   0   0  -1   0   0   0   0   0;  # x12 - 5 y2 - s9 = 0
        0   0   0   0   1   0   0  -9   0   0   0   0   0   0   0   0   0   1   0   0   0   0;  # x12 - 9 y2 + s10 = 0
        0   0   0   0   0   1   0   0   0   0   0   0   0   0   0   0   0   0  -1   0   0   0;  # x22 - s11 = 0
        0   0   0   0   0   1   0  -M   0   0   0   0   0   0   0   0   0   0   0   1   0   0;  # x22 - M y2 + s12 = 0
        0   0   0   0   0   1   0  -4   0   0   0   0   0   0   0   0   0   0   0   0  -1   0;  # x22 - 4 y2 - s13 = 0
        0   0   0   0   0   1   0  -6   0   0   0   0   0   0   0   0   0   0   0   0   0   1;  # x22 - 6 y2 + s14 = 0
    ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];

c = ones(Ban, size(A,2), 1) .* [ 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0];

B = [ 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 20, 21 ];

na_simplex(A, b, c, B);

print("THE END");
