include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");

using .BAN

#=
SIMPLE DISJUNCTIVE PROBLEM - BIG-M REFORMULATION + NA SIMPLEX
This script solves a simple disjunctive-constraints problem using the
Big-M reformulation and the NA Simplex.
This topic is described in subsection 1.3.1.
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#


M = α

A = [#x1  x2 y1  y2  s1  s2  s3  s4  s5  s6  s7  s8
      1   0   M   0   1   0   0   0   0   0   0   0;  # x1 + M y1 + s1 = M + 3
      1   0  -M   0   0  -1   0   0   0   0   0   0;  # x1 - M y1 - s2 = -M
      0   1   M   0   0   0   1   0   0   0   0   0;  # x2 + M y1 + s3 = M + 4
      0   1  -M   0   0   0   0  -1   0   0   0   0;  # x2 - M y1 - s4 = -M
      1   0   0   M   0   0   0   0   1   0   0   0;  # x1 + M y2 + s5 = M + 9
      1   0   0  -M   0   0   0   0   0  -1   0   0;  # x1 - M y2 - s6 = -M + 5
      0   1   0   M   0   0   0   0   0   0   1   0;  # x2 + M y2 + s7 = M + 6
      0   1   0  -M   0   0   0   0   0   0   0  -1;  # x2 - M y2 - s8 = -M + 4
      0   0   1   1   0   0   0   0   0   0   0   0;  # y1 + y2 = 1
    ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ M+3, -M, M+4, -M, M+9, -M+5, M+6, -M+4, 1 ];

c = ones(Ban, size(A,2), 1) .* [ 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];

B = [ 3, 5, 6, 7, 8, 9, 10, 11, 12 ];

na_simplex(A, b, c, B);

print("THE END");
