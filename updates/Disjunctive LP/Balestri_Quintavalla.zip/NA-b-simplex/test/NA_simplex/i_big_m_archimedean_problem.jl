include("../../src/NA_simplex/I_Big_M.jl");
include("../../src/BAN.jl");

using .BAN

#=
SIMPLE ARCHIMEDEAN PROBLEM - I BIG-M METHOD
This script solves a simple archimedean problem using the I Big-M method.
This topic is described in subsection 1.4.
The problem is described at the following link:
https://en.wikipedia.org/wiki/Revised_simplex_method
=#

A = [#x1 x2 x3
      3  2  1;  # 3x1 + 2x2 + x3 = 10
      2  5  3;  # 2x1 + 5x2 + 3x3 = 15
      ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A, 1), 1) .* [ 10, 15 ];

c = ones(Ban, size(A, 2), 1) .* [ 2, 3, 4];

tol = one(Ban)*1.e-5;

t = [-1, -1];

I_Big_M(A, b, c, t, eps=tol, verbose=true);

print("THE END");
