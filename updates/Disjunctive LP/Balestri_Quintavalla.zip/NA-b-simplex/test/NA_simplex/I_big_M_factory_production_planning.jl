include("../../src/NA_simplex/I_Big_M.jl");
include("../../src/BAN.jl");

using .BAN

#=
FACTORY PRODUCTION PLANNING - CONVEX HULL REFORMULATION + I BIG-M METHOD
This script solves the factory production problem using the convex hull
reformulation and the I Big-M method.
This topic is described in subsection 5.1.
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities#:~:text=A%20disjunctive%20inequality%20is%20a,related%20by%20an%20OR%20statement.
Data are chosen at random. Different experiments performed are commented.
=#

M = α
E1 = 0.5 # 1, 2, 4
E2 = 1  #  1, 3, 2
FC1 = 3  # 3, 4, 6
FC2 = 3  # 3, 2, 3
VC1 = 1  # 1, 3, 5
VC2 = 1  # 1, 2, 1
PC = 4
PB = 2
B = 10

A = [#x1  x2   x11  x21  x12  x22  y1   y2   x1 represents the quantity of C produced, while x2 represents the cost
      1    0   -1    0   -1    0    0    0 ;  # x1 - x11 - x12 = 0
      0    1    0   -1    0   -1    0    0 ;  # x2 - x21 - x22 = 0
      0    0    0    0    0    0    1    1 ;  # y1 + y2 = 1
      0    0    1    0    0    0    0    0 ;  # x11 >= 0
      0    0    1    0    0    0   -M    0 ;  # x11 - M y1 <= 0
      0    0    0    1    0    0    0    0 ;  # x21 >= 0
      0    0    0    1    0    0   -M    0 ;  # x21 - M y1 <= 0
      0    0    0    0    1    0    0    0 ;  # x12 >= 0
      0    0    0    0    1    0    0   -M ;  # x12 - M y2 <= 0
      0    0    0    0    0    1    0    0 ;  # x22 >= 0
      0    0    0    0    0    1    0   -M ;  # x22 - M y2 <= 0
      0    0    1    0    0    0  -E1*B  0 ;  # x11 - E1 B y1 = 0
      0    0  -VC1   1    0    0  -FC1   0 ;  # -VC1 x11 + x21 - FC1 y1 = 0
      0    0    0    0    1    0    0 -E2*B;  # x12 - E2 B y2 = 0
      0    0    0    0  -VC2   1    0  -FC2;  # -VC2 x12 + x22 - FC2 y2 = 0

];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ];

t = [0, 0, 0, 1, -1, 1, -1, 1, -1, 1, -1, 0, 0, 0, 0];

c = ones(Ban, size(A,2), 1) .* [ PC, -1, 0, 0, 0, 0, 0, 0];

tol = one(Ban)*1.e-5;

I_Big_M(A, b, c, t, eps=tol, verbose=true);

print("THE END");

#=
In order to see which plan is chosen, it's sufficient to see the results
obtained for y1 and y2.
=#
