include("../../src/NA_simplex/I_Big_M.jl");
include("../../src/BAN.jl");

using .BAN

#=
SIMPLE DISJUNCTIVE PROBLEM - BIG-M REFORMULATION + I BIG-M METHOD
This script solves a simple disjunctive-constraints problem using Big-M
reformulation and I Big-M method.
This topic is described in subsection 1.6.1.
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#

M = α

A = [ # x1 x2 y1 y2
        -1  0  M  0;  # -x1 + My1 <= 0
         1  0  M  0;  # x1 + M y1 <= 0
         0 -1  M  0;  # -x2 + M y1 <= 0
         0  1  M  0;  # x2 + M y1 <= 0
        -1  0  0  M;  # -x1 + M y2 <= 0
         1  0  0  M;  # x1 + M y2 <= 0
         0 -1  0  M;  # -x2 + M y2 <= 0
         0  1  0  M;  # x2 + M y2 <= 0
         0  0  1  1;  # y1 + y2 = 1
    ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ M, M+3, M, M+4, M-5, M+9, M-4, M+6, 1 ];

c = ones(Ban, size(A,2), 1) .* [ 1, 1, 0, 0];

tol = one(Ban)*1.e-5;

t = [ -1, -1, -1, -1, -1, -1, -1, -1, 0 ];

I_Big_M(A, b, c, t, eps=tol, verbose=true);

print("THE END");
