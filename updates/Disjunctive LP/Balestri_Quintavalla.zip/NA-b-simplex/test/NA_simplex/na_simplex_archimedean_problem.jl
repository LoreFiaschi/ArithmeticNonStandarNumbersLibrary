include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");
include("../../src/NA_simplex/NA_Simplex2.jl");

using .BAN

#=
SIMPLE ARCHIMEDEAN PROBLEM - NA SIMPLEX
This script solves the Simple Archimedean Problem using NA Simplex.
This topic is described in subsection 1.1.
The problem is described at the following link:
https://en.wikipedia.org/wiki/Revised_simplex_method
=#


A = [#x1 x2  x3  s1  s2
      3   2   1   1   0;  # 3 x1 + 2 x2 + x3 + s1 = 10
      2   5   3   0   1;  # 2 x1 + 5 x2 + 3 x3 + s2 = 15
    ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A, 1), 1) .* [ 10, 15 ];

c = ones(Ban, size(A, 2), 1) .* [ 2, 3, 4, 0, 0];

B = [ 4, 5 ];

na_simplex(A, b, c, B);

print("THE END");
