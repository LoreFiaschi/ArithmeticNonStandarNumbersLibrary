include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");
include("../../src/NA_simplex/NA_Simplex2.jl");

using .BAN

#=
BENCHMARK PROBLEMS TO SEE THE DIFFERENCE BETWEEN NA SIMPLEX and NA SIMPLEX2
This script is used to see the difference between the two versions of the Simplex.
This topic is described in section 4.
The first problem is the one that makes the difference emerge. In order to do so,
comment the last denoise (line 252) in NA_Simplex.jl.
The second problem below (commented) is not able to show the difference.
=#


A = [ #x1     #x2   #s1   #s2   #s3
       1       0     1     0     0 ;  # x1 + s1 = 1
       0       1     0     1     0 ;  # x2 + s2 = 1
       0.5    η-1    0     0    -1 ;  # 0.5 x1 + (η-1)x2 - s3 = 0.5(η-1)
];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 1, 1, 0.5η-0.5];

c = ones(Ban, size(A,2), 1) .* [ η, η, 0, 0, 0 ];

B = [1, 2, 3];  # (1,2,3) corrisponde a (1-η, 1)

opt_value2, opt_solution2, opt_basis2, iter2 = na_simplex2(A, b, c, B, η);
opt_value, opt_solution, opt_basis, iter = na_simplex(A, b, c, B, η);

println("OPTIMAL VALUE SIMPLEX2");
println(opt_value2);
println("OPTIMAL SOLUTION SIMPLEX2");
println(opt_solution2);
println("OPTIMAL VALUE SIMPLEX");
println(opt_value);
println("OPTIMAL SOLUTION SIMPLEX");
println(opt_solution);

print("THE END");

#=

A = [ #x1   #x2   #s1   #s2
       1     0     1     0  ;  # x1 + s1 = η
       0     1     0     1  ;  # x2 + s2 = η
];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ η, η ];

c = ones(Ban, size(A,2), 1) .* [ α, α, 0, 0 ];

B = [3, 4]; # (3,4) corresponds to the point (0 0), (1,2) corresponds to the point (η η)

opt_value2, opt_solution2, opt_basis2, iter2 = na_simplex2(A, b, c, B);
opt_value, opt_solution, opt_basis, iter = na_simplex(A, b, c, B);

println("OPTIMAL VALUE SIMPLEX2");
println(opt_value2);
println("OPTIMAL SOLUTION SIMPLEX2");
println(opt_solution2);
println("OPTIMAL VALUE SIMPLEX");
println(opt_value);
println("OPTIMAL SOLUTION SIMPLEX");
println(opt_solution);

print("THE END");

=#
