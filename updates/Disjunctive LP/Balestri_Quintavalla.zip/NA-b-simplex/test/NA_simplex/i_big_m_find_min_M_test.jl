include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");
include("../../src/NA_simplex/I_Big_M.jl");

using .BAN

#=
FINDING MINIMAL M FOR WHICH THE I BIG M METHOD IS ABLE TO FIND THE OPTIMAL SOLUTION
This script finds the minimal M that gives the optimal value (with a certain tolerance).
This problem is described in section 3.
=#

#=
This function takes as input the constraints of the two disjuctive regions (a vector
of 8 elements specifying region 1 lower bound on x1, upper bound on x1, lower bound
on x2, upper bound on x2, region 2 lower bound on x1, upper bound on x1, lower bound
on x2, upper bound on x2) and the value of M. It returns the A matrix.
=#

function give_me_A(a::AbstractVector{T}, M::Number) where T <: Number

      A = [#x1  x2   x11  x21  x12  x22  y1   y2
            0    0    1    0    0    0    0    0 ;  # x11 >= 0
            0    0    0    1    0    0    0    0 ;  # x21 >= 0
            0    0    0    0    1    0    0    0 ;  # x12 >= 0
            0    0    0    0    0    1    0    0 ;  # x22 >= 0
            0    0    1    0    0    0   -M    0 ;  # x11 - My1 <= 0
            0    0   -1    0    0    0   a[1]  0 ;  # -x11 + 1y1 <= 0
            0    0    1    0    0    0  -a[2]  0 ;  # x11 - 3y1 <= 0
            0    0    0    1    0    0   -M    0 ;  # x21 - My1 <= 0
            0    0    0   -1    0    0   a[3]  0 ;  # -x21 + 1y1 <= 0
            0    0    0    1    0    0  -a[4]  0 ;  # x21 - 4y1 <= 0
            0    0    0    0    1    0    0   -M ;  # x12 - My2 <= 0
            0    0    0    0   -1    0    0  a[5];  # -x12 + 5y2 <= 0
            0    0    0    0    1    0    0 -a[6];  # x12 - 9y2 <= 0
            0    0    0    0    0    1    0   -M ;  # x22 - My2 <= 0
            0    0    0    0    0   -1    0  a[7];  # -x22 + 4y2 <= 0
            0    0    0    0    0    1    0 -a[8];  # x22 - 6y2 <= 0
            1    0   -1    0   -1    0    0    0 ;  # x1 - x11 - x12 = 0
            0    1    0   -1    0   -1    0    0 ;  # x2 - x21 - x22 = 0
            0    0    0    0    0    0    1    1 ;  # y1 + y2 = 1
          ];

    A = convert(Matrix{Ban}, A);

    return A;

end

#=
This function takes as input the vector of regions boundaries (see above for
description), the initial M, the step used for M and a tolerance for the
optimal value, and it prints the minimal M found. 
=#
function find_min_M(a::AbstractVector{T}, starting_M::Int, step::Int,
    tolerance::Real) where T <: Number

    tolerance = one(Ban)*tolerance;

    A = give_me_A(a,α);

    b = ones(Ban, size(A,1), 1) .* [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 ];

    c = ones(Ban, size(A,2), 1) .* [ 1, 1, 0, 0, 0, 0, 0, 0 ];

    tt = one(Ban)*1.e-5;

    t = [ 1, 1, 1, 1 , -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  0,  0,  0 ];

    opt_value, opt_solution, opt_base, iter = I_Big_M(A, b, c, t, eps=tt, verbose=false);
    curr_opt_value = nothing;
    curr_opt_solution = nothing;
    curr_opt_base = nothing;
    curr_iter = nothing;
    error = nothing;

    while (true)

          A = give_me_A(a, starting_M);

          try

              curr_opt_value, curr_opt_solution, curr_opt_base, curr_iter = I_Big_M(A, b, c, t, eps=tt, verbose=false);

          catch e

              println("\tUnfeasible problem\n");
              global starting_M += step;
              continue;

          end

          error = abs(opt_value[1] - curr_opt_value[1]);

          if error <= tolerance

                println("");
                print("\tMinimal M found: ");println(starting_M);print("\n");
                return starting_M;

          end

          starting_M += step;

    end

end

find_min_M([0, 3, 0, 4, 900, 1000, 600, 700], 980, 1, 1e-10);
