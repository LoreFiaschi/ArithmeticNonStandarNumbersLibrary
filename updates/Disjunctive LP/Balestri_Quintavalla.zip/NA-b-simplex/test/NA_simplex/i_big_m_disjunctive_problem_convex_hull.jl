include("../../src/NA_simplex/I_Big_M.jl");
include("../../src/BAN.jl");

using .BAN

#=
SIMPLE DISJUNCTIVE PROBLEM - CONVEX HULL REFORMULATION + I BIG-M METHOD
This script solves a simple disjunctive-constraints problem using Convex Hull
reformulation and I Big-M method.
This topic is described in subsection 1.6.2.
The problem is described at the following link:
https://optimization.mccormick.northwestern.edu/index.php/Disjunctive_inequalities
=#

M = α;

A = [ #x1  x2  x11 x21 x12 x22 y1  y2
        0   0   1   0   0   0   0   0;  # x11 >= 0
        0   0   0   1   0   0   0   0;  # x21 >= 0
        0   0   0   0   1   0   0   0;  # x12 >= 0
        0   0   0   0   0   1   0   0;  # x22 >= 0
        0   0   1   0   0   0  -M   0;  # x11 - My1 <= 0
        0   0   1   0   0   0  -3   0;  # x11 - 3y1 <= 0
        0   0   0   1   0   0  -M   0;  # x21 - My1 <= 0
        0   0   0   1   0   0  -4   0;  # x21 - 4y1 <= 0
        0   0   0   0   1   0   0  -M;  # x12 - My2 <= 0
        0   0   0   0  -1   0   0   5;  # -x12 + 5y2 <= 0
        0   0   0   0   1   0   0  -9;  # x12 - 9y2 <= 0
        0   0   0   0   0   1   0  -M;  # x22 - My2 <= 0
        0   0   0   0   0  -1   0   4;  # -x22 + 4y2 <= 0
        0   0   0   0   0   1   0  -6;  # x22 - 6y2 <= 0
        1   0  -1   0  -1   0   0   0;  # x1 - x11 - x12 = 0
        0   1   0  -1   0  -1   0   0;  # x2 - x21 - x22 = 0
        0   0   0   0   0   0   1   1;  # y1 + y2 = 1
    ];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 ];

c = ones(Ban, size(A,2), 1) .* [ 1, 1, 0, 0, 0, 0, 0, 0 ];

tol = one(Ban)*1.e-5;

t = [  1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0 ];

I_Big_M(A, b, c, t, eps=tol, verbose=false);

print("THE END");
