include("../../src/NA_simplex/I_Big_M.jl");
include("../../src/BAN.jl");

using .BAN

#=
NA KYTE PROBLEM - I BIG-M METHOD
This script solves the NA Kyte problem using the I Big-M Method.
This topic is described in subsection 1.5.
The problem is described at the following link:
https://link.springer.com/article/10.1007/s11590-020-01644-6
=#

A = [#z1  z2  z3
      2   1  -3;  # 2 z1 + z2 - 3 z3 <= 90
      2   3  -2;  # 2 z1 + 3 z2 - 2z3 <= 190
      4   3   3;  # 4 z1 + 3 z2 + 3 z3 <= 300
      0   0   1;  # z3 = 10
      1   2   1;  # z1 + 2 z2 + z3 >= 70
];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 90, 190, 300, 10, 70 ];

c = ones(Ban, size(A,2), 1) .* [ 8+14η, 12+10η, 7+2η ];

tol = one(Ban)*1.e-5;

t = [-1, -1, -1, 0, 1];

I_Big_M(A, b, c, t, eps=tol, verbose = true);

print("THE END");
