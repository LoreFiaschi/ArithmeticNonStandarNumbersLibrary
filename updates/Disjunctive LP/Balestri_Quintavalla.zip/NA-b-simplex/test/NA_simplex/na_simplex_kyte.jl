include("../../src/NA_simplex/NA_Simplex.jl");
include("../../src/BAN.jl");
include("../../src/NA_simplex/NA_Simplex2.jl");

using .BAN

#=
NA KYTE PROBLEM - NA SIMPLEX
This script solves the NA Kyte problem using the NA Simplex.
This topic is described in subsection 1.2.
The problem is described at the following link:
https://link.springer.com/article/10.1007/s11590-020-01644-6
=#

A = [#z1 z2  z3  s1  s2  s3   e   r   p
      2   1  -3   1   0   0   0   0   0;  # 2 z1 + z2 - 3 z3 + s1 = 90
      2   3  -2   0   1   0   0   0   0;  # 2 z1 + 3 z2 - 2 z3 + s2 = 190
      4   3   3   0   0   1   0   0   0;  # 4 z1 + 3 z2 + 3 z3 + s3 = 300
      0   0   1   0   0   0   1   0   0;  # z3 + e = 10
      1   2  -1   0   0   0   0   1  -1;  # z1 + 2 z2 - z3 + r - p = 0
];

A = convert(Matrix{Ban}, A);

b = ones(Ban, size(A,1), 1) .* [ 90, 190, 300, 10, 70 ];

c = ones(Ban, size(A,2), 1) .* [ 8+14η, 12+10η, 7+2η, 0, 0, 0, -α, -α, 0 ];

B = [ 4, 5, 6, 7, 8 ];

na_simplex2(A, b, c, B);

print("THE END");
