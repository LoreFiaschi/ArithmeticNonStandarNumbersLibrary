using ProgressMeter  # already existing library

function na_simplex(A::Matrix{T},b::Array{T,2},c::Array{T,2},B::Array{Int64,1},
						eps::Number=convert(promote_type(T,Float64),1e-5),verbose::Bool=true,genLatex::Bool=false,
						showprogress::Bool=false) where T <: Number

	# T <: Number means that T is a subtype of Number
	# convert = convert 1e-5 nel type ottenuto dalla promozione di Float64 in T (quindi anche Non-Archimedian)
	# promote_type = given any number of type objects, returns the common type to which those values,
	# as arguments to promote should be promoted

	# The method implements the revised simplex method in Box 7.1 on page 103 of Chvatal

	# Revised Simplex
	#
	# max  c'*x
	# s.t. Ax = b
	#      x >= 0

	# number of rows of A = n_constraints
	# number of columns of A = n_variables

	n_constraints, n_variables = size(A);

	# Set of elements in 1:n_variables but not in B: non-base indexes
    N = setdiff(1:n_variables, B);

    # Assume rank non-deficient initial base matrix
	# A[:,B] is the submatrix of A consisting of the columns indexed by the elements of B
    xB = inv(A[:,B])*b;

	#any means for at least one; -> is a lambda function; any value of xB < 0
    any(x->x<-eps, xB) && (println(""); true;) && (println(eps); println(""); println(xB[findall(x->x<-eps, xB)]); true;) && error("Unfeasible problem")
    #any(x->x<0, xB) && (println(""); true;) && (println(xB); true;) && (println(b); true;) && error("Unfeasible problem")

	# Create array of zeros (type T) of size n_variables (per metterci le soluzioni)
    x = zeros(T, n_variables);
    x[B] = xB;

	# the map() function collects the results of some function working on each and every element of an iterable object
	aux_var = map(z->z[1], findall(z->z.p>0, c));

    if genLatex
        println("\\begin{table}[!ht]");
        println("\t\\centering");
        println("\t\\caption{}");
        println("\t\\begin{tabular}{|c|c|c|c|}");
        println("\t\\hline");
        println("\t\\textbf{Iter.} & \\textbf{Base} & \$ \\mathbf{x}^* \$ & \$ \\tilde{\\mathbf{c}}^T \\mathbf{x}^* \$ \\\\");
        println("\t\\hline");
    elseif showprogress
		prog = ProgressUnknown("Iteration:");
	end

    iter = 0;
    while true
        iter +=1;

        if genLatex
            print("\t$iter & \$ \\{$(B[1])");
            for elem in B[2:end]
            print(",\\, $elem");
            end
            print("\\} \$ & \$ ");
			print_latex(x);
			print(" \$ & \$ ");
			print_latex((c'*x)[1]);
            println(" \$ \\\\");
            println("\t\\hline");
        elseif verbose
            println("Iteration: $iter");
            println(string("\tB: ", B));
            print("\tCost: ")
            println((c'*x)[1])
            print("\tSolution: ");
            println(x);
            println("");
		elseif showprogress
			ProgressMeter.next!(prog);
        end

		#=
		for r in eachrow(A[:,B])
			println(r);
		end
		println("");
		=#

        inv_A_B = inv(A[:,B]);

		# considera tutti i possibili valori di c[N] - A[:,N]'*y' a seconda di N. Se non esiste
		# un N per cui questo valore è positivo (i.e. > eps), x è la optimal solution
        y = c[B]'*inv_A_B;

        sN = c[N] - A[:,N]'*y';
		#print("sN: "); println(sN);
		#println("");
		sN = denoise(sN, eps[1]); # DANGER!! entries can change sign, is it a problem? Forse no se guardiamo al valore assoluto rispetto a eps.

		print("sN: "); println(sN);
		println("");

		# Gradient Descent
        # k = argmax(sN);
        # k_val = sN[k];

		# Bland Rule
		# Trova il primo indice N tale che sN sia positivo (i.e. > eps)
		ind_of_pos = findfirst(x->x>eps, sN); # TODO modify in the external version of >  if considered necessary
		# Se non esiste allora siamo già all'ottimo
		if ind_of_pos == nothing  # con questa condizione esco (tra qualche riga)
			k_val = -1;
		    k = [];
		else
		 	#k = not_aux_var_N[ind_of_pos];
		 	k = ind_of_pos;
			k_val = sN[k];
		end

		#=
		print("k_val: "); println(k_val);
		print("k: "); println(k);
		println("");
		#println("");
		=#

		#degree_improvement = findfirst(x->x>0, k_val.num);

		#=NEW
		if is_array_lower_than_threshold(sN, 1e-5) && degree(????)
		=#

        if k_val < 0 #degree_improvement==nothing || any(x->x<=0, (k_val-eps).num[1:degree_improvement])
            #x[B] = xB;

			#=
			for i in 1:length(x)

				x[i] = standard_part(x[i]);

			end=#

            obj = c'*x;

            if genLatex
                println("\\end{tabular}");
                println("\\label{tab:}")
                println("\\end{table}");
                println("");
			elseif showprogress
				ProgressMeter.finish!(prog);
            end

			print("Optimization completed, ");
			(all(z->z==0, denoise(x[aux_var], eps[1]))) ? println("feasible solution found") : println("unfeasible solution found");
			println("Resume:");
			println("\ttotal iterations: $iter");
			print("\tobjective function: "); println(obj);
			print("\tappr. optimal solution: "); print(approximate_BAN_vector(x)); print("\n");
			print("\toptimal base: "); print(B);
			println("");
			#=
			println("")
			println("DEBUG")
			println("");

			inv_A_B = inv(A[:,B]);
			y = c[B]'*inv_A_B;
			sN = c[N] - A[:,N]'*y';
			println("sN: ");
			for s in sN
				println(s);
			end
			=#

            return obj, x, B, iter;
        end
        # find d = [d1,..., dn]' such that dk = 1, dj = 0 for all j belongin to N\{k}, and
		# A_B*d_B = -A_k. Credo manchi un meno qui ma dopo con zz guarda se ci sono positivi e se non ci sono dice che
		# il problema è unbounded, mentre in teoria il problema è unbounded se ci sono positivi.
        d = denoise(inv_A_B*A[:,N[k]], eps[1]);
        #print("d_pre: "); println(d); println("");

		# zz contiene tutti gli indici di d per i quali d > 0
		zz = findall(x->x>0, d); # it works thanks to previous denoise

		# se non ne trovi, il prolema è unbounded
        if isempty(zz)

			#il valore ottimo è infinito
            obj = convert(T, Inf);

			#la soluzione ottima è Nan (ogni elemento del vettore x è settato a Nan)
            x .= NaN;
            verbose && println("Problem unbounded");
            return obj, x, B, iter
        end

		# prendi gli elementi di x relativi agli indici per cui d > 0, e
		# dividi ciascuno di questi elementi per il corrispondente d_i > 0
        quality = xB[zz]./d[zz];
		#ii è l'indice relativo al valore minimo del vettore quality
        ii = argmin(quality);
		#theta è il minimo del vettore quality
        theta = quality[ii];

		#= DEBUGGING =#
		print("xB: "); println(xB[zz]);
		print("d: "); println(d[zz]);
		println("");
		print("quality: "); println(quality);
		print("theta: "); println(theta);
		print("ii: "); println(ii);
		println("");
		println("");


		#=
		aggiorno il vettore x (nelle posizioni relative agli indici di base)
		sottraendo a ciascun elemento il prodotto theta*d (nota che d è un vettore
		di dimensione pari a x[B])
		=#
        x[B] -= theta*d;

		#=
		N è l'insieme degli indici non di base
		k è l'indice entrante (quindi un indice non di base)
		prende dal vettore x il k-esimo indice non di base (N) e lo mette a theta
		=#
		x[N[k]] = theta;

		#Aggiungi k alla base e togli l
		#=
		zz è l'insieme di indici per cui d > 0
		ii è l'indice in cui il vettore quality è minimo
		l sarà l'indice, tra quelli per cui d > 0, che minimizza quality
		=#
		l = zz[ii]

		#=
		leaving_index è l'indice uscente
		=#
        leaving_index = B[l];

		#=
		scambio indice entrante e indice uscente nei vettori B ed N
		=#
        B[l] = N[k];
        N[k] = leaving_index;

		xB = x[B];  # xB is a new array (later modifications on x will not impact xB)
		x = denoise(x, eps[1]);
    end
end
